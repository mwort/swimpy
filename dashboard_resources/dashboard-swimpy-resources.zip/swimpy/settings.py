"""These are test settings of SWIMpy."""
import os.path as osp
from modelmanager.plugins.grass import GrassAttributeTable as _GAT
import numpy as np
import pandas as pd

from swimpy.grass import hydrotopes as _swimpy_hydrotopes
from swimpy.dashboard import App as dashboard


# path outside project dir dynamic relative to resourcedir to work with clones
grass_db = property(lambda p: osp.join(osp.realpath(p.resourcedir), '..', '..', 'grassdb'))
grass_location = "utm32n"
grass_mapset = "swim"
grass_setup = dict(elevation="elevation@PERMANENT",
                   stations="stations@PERMANENT",
                   upthresh=50, lothresh=1.6, streamthresh=200,
                   predefined="reservoirs@PERMANENT",
                   landuse="landuse@PERMANENT",
                   soil="soil@PERMANENT")

cluster_slurmargs = dict(qos='priority')


def _read_q():
    cols = ['y', 'm', 'd', 'BLANKENSTEIN']
    path = osp.join(osp.dirname(__file__), '../input/runoff.dat')
    q = pd.read_csv(path, skiprows=2, header=None, delim_whitespace=True,
                    index_col=0, parse_dates=[[0, 1, 2]], names=cols,
                    na_values=[-9999])
    q.index = q.index.to_period()
    q['HOF'] = q['BLANKENSTEIN']*0.5
    return q


class stations:
    def __init__(self, project):
        self.project = project

    @property
    def daily_discharge_observed(self):
        return _read_q()


class hydrotopes(_swimpy_hydrotopes):

    array_file = osp.join(osp.dirname(__file__), "hydrotopes.bin")
    array_na = 0
    array_shape = (446, 482)
    array_latlon_bounds = [(50.50394243, 11.56237908), (50.08653291, 12.21395716)]

    @property
    def array(self):
        array = np.fromfile(self.array_file, dtype=np.int32).reshape(self.array_shape)
        return array

    def to_image(self, hydrotope_series, output_path):
        from matplotlib.pyplot import imsave

        # reclass hyd array
        fltarr = self.array.flatten()
        newarr = np.zeros_like(fltarr, dtype=float)
        newarr[fltarr != self.array_na] = hydrotope_series[fltarr[fltarr != self.array_na]]
        #newarr[fltarr == self.array_na] = np.nan
        recarr = np.reshape(newarr, self.array.shape)
        imsave(output_path, recarr, origin="upper")
        return